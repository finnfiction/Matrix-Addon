Hello,
my name is Finn.
I wrote this while i was learning Python.
I can fully recommend the "Python in Blender" course by "Coloremblem"
and the Programming learning App "SoloLearn".


Bye.