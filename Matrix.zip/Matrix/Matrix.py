bl_info = {
    "name":        "Matrix",
    "description": "Flow optimized Random and Matrix Tools",
    "author":      "finnfiction",
    "version":     (1, 0, 0),
    "blender":     (2, 8, 0),
	"location":    "View 3D > Tool Shelf > Random",
    "category":    "Object"
    }








#Set Up
import bpy
import random as rand
from bpy.props import IntProperty, FloatProperty, StringProperty, BoolProperty, EnumProperty
word = 'hello'
iterations = 0

bpy.types.Scene.lengthProperty = bpy.props.IntProperty(name = 'length', default = 10 , min = 1)
bpy.types.Scene.verticalProperty = bpy.props.BoolProperty(name = 'vertical', default = False)
bpy.types.Scene.matrixProperty = bpy.props.BoolProperty(name = 'individual randomization', default = False)
bpy.types.Scene.xProperty = bpy.props.FloatProperty(name = 'x radius', default = 10 , min = 0)
bpy.types.Scene.yProperty = bpy.props.FloatProperty(name = 'y radius', default = 10 , min = 0)
bpy.types.Scene.zProperty = bpy.props.FloatProperty(name = 'z radius', default = 0 , min = 0)
bpy.types.Scene.amountProperty = bpy.props.IntProperty(name = 'amount', default = 25 , min = 1)
#Panel
class Random(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
    bl_label = 'Matrix'
    bl_category = 'Matrix'
    
    def draw(self, context):
        self.layout.label('text creator', icon = 'OUTLINER_OB_FONT')
        self.layout.operator('create.text')
        self.layout.operator('')
        col = self.layout.column(align=True)
        lay = self.layout
        col.label('text randomizer', icon = 'IPO')
        col.operator('random.text')
        col.operator('binary.text')
        col.prop(bpy.context.scene, 'lengthProperty')
        col.prop(bpy.context.scene, 'verticalProperty')
        col.label('text replicator', icon = 'OUTLINER_DATA_MESH')
        col.prop(bpy.context.scene, 'amountProperty')
        col.prop(bpy.context.scene, 'xProperty')
        col.prop(bpy.context.scene, 'yProperty')
        col.prop(bpy.context.scene, 'zProperty')
        col.prop(bpy.context.scene, 'matrixProperty')
        lay.operator('random.replicator')
        
        
#Button
class OBJECT_OT_randomtext(bpy.types.Operator):
    bl_label = 'Random Text'
    bl_idname = 'random.text'
    bl_description = 'generates randomized Text'
    
    
    
    def execute(self, context):
        word = ''
        i = bpy.context.scene.lengthProperty
        if bpy.context.scene.verticalProperty == True:
            while i > 0:
                word += rand.choice('abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
                i -= 1
            print(word)
            i = bpy.context.scene.lengthProperty
            bpy.ops.object.editmode_toggle()
            bpy.ops.font.select_all()
            bpy.ops.font.text_insert(text=word)
            while i > 0:
                bpy.ops.font.line_break()
                bpy.ops.font.move(type='NEXT_CHARACTER')
                i -= 1
            bpy.context.object.data.space_line = 0.85
            bpy.ops.object.editmode_toggle()
        else:
            while i > 0:
                word += rand.choice('abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ')
                i -= 1
            print(word)
            bpy.ops.object.editmode_toggle()
            bpy.ops.font.select_all()
            bpy.ops.font.text_insert(text=word)
            bpy.context.object.data.space_line = 1
            bpy.ops.object.editmode_toggle()
        return{'FINISHED'}

class OBJECT_OT_randombinarytext(bpy.types.Operator):
    bl_label = 'Random binary Text'
    bl_idname = 'binary.text'
    bl_description = 'generates randomized binary Text'
    
    def execute(self, context):
        word = ''
        i = bpy.context.scene.lengthProperty
        if bpy.context.scene.verticalProperty == True:
            while i > 0:
                word += rand.choice('10')
                i -= 1
            print(word)
            i = bpy.context.scene.lengthProperty
            bpy.ops.object.editmode_toggle()
            bpy.ops.font.select_all()
            bpy.ops.font.text_insert(text=word)
            while i > 0:
                bpy.ops.font.line_break()
                bpy.ops.font.move(type='NEXT_CHARACTER')
                i -= 1
            bpy.context.object.data.space_line = 0.85
            bpy.ops.object.editmode_toggle()
        else:
            while i > 0:
                word += rand.choice('10')
                i -= 1
            print(word)
            bpy.ops.object.editmode_toggle()
            bpy.ops.font.select_all()
            bpy.ops.font.text_insert(text=word)
            bpy.context.object.data.space_line = 1
            bpy.ops.object.editmode_toggle()
        return{'FINISHED'}
    
class OBJECT_OT_textcreator(bpy.types.Operator):
    bl_label = 'Create Text'
    bl_idname = 'create.text'
    bl_description = 'creates text object'
    
    def execute(self, context):
        bpy.ops.object.text_add(radius=1, view_align=False, enter_editmode=False, location=(0, 0, 0), layers=(True, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False))
        return{'FINISHED'}
    
class OBJECT_OT_randomReplicator(bpy.types.Operator):
    bl_label = 'Random Replicatior'
    bl_description = 'replicates Object randomly in assigned Space'
    bl_idname = 'random.replicator'
    
    def execute(self, context):
        x = bpy.context.scene.xProperty
        y = bpy.context.scene.yProperty
        z = bpy.context.scene.zProperty
        i = bpy.context.scene.amountProperty
        l = bpy.context.scene.lengthProperty
        if bpy.context.scene.matrixProperty == False:
            while i > 0:
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={'linked':False, 'mode':'TRANSLATION'}, TRANSFORM_OT_translate={'value':(0,0,0), 'constraint_axis':(True, False, False), 'constraint_orientation':'GLOBAL', 'mirror':False, 'proportional':'DISABLED', 'proportional_edit_falloff':'SMOOTH', 'proportional_size':1, 'snap':False, 'snap_target':'CLOSEST', 'snap_point':(0, 0, 0), 'snap_align':False, 'snap_normal':(0, 0, 0), 'gpencil_strokes':False, 'texture_space':False, 'remove_on_cancel':False, 'release_confirm':False})
                bpy.ops.transform.translate(value= ((((rand.random()*x*2)-x)), ((rand.random()*y*2)-y), ((rand.random()*z*2)-z)))
                i -= 1
        else:
            while i > 0:
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={'linked':False, 'mode':'TRANSLATION'}, TRANSFORM_OT_translate={'value':(0,0,0), 'constraint_axis':(True, False, False), 'constraint_orientation':'GLOBAL', 'mirror':False, 'proportional':'DISABLED', 'proportional_edit_falloff':'SMOOTH', 'proportional_size':1, 'snap':False, 'snap_target':'CLOSEST', 'snap_point':(0, 0, 0), 'snap_align':False, 'snap_normal':(0, 0, 0), 'gpencil_strokes':False, 'texture_space':False, 'remove_on_cancel':False, 'release_confirm':False})
                bpy.ops.transform.translate(value= ((((rand.random()*x*2)-x)), ((rand.random()*y*2)-y), ((rand.random()*z*2)-z)))
                word = ''
                if bpy.context.scene.verticalProperty == True:
                    l = bpy.context.scene.lengthProperty
                    while l > 0:
                        word += rand.choice('10')
                        l -= 1
                    bpy.ops.object.editmode_toggle()
                    bpy.ops.font.select_all()
                    bpy.ops.font.text_insert(text=word)
                    l = bpy.context.scene.lengthProperty
                    while l > 0:
                        bpy.ops.font.line_break()
                        bpy.ops.font.move(type='NEXT_CHARACTER')
                        l -= 1
                    
                    bpy.context.object.data.space_line = 0.85
                    bpy.ops.object.editmode_toggle()

                else:
                    while l > 0:
                        word += rand.choice('10')
                        l -= 1
                    print(word)
                    bpy.ops.object.editmode_toggle()
                    bpy.ops.font.select_all()
                    bpy.ops.font.text_insert(text=word)
                    bpy.context.object.data.space_line = 1
                    bpy.ops.object.editmode_toggle()
                i -= 1
                
        return{'FINISHED'}
        

#Automation     
def register():
    bpy.utils.register_module(__name__)
    
def unregister():
    bpy.utils.unregister_module(__name__)
    
if __name__ == '__main__':
    register()

    
